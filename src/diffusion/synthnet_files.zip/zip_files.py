import os
import zipfile

# Directory containing the files
data_dir = '/mnt/data'
zip_path = '/mnt/data/synthnet_files.zip'

# Create zip archive
with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
    for root, dirs, files in os.walk(data_dir):
        for file in files:
            # Exclude the zip file itself if regenerating
            if file == os.path.basename(zip_path):
                continue
            file_path = os.path.join(root, file)
            arcname = os.path.relpath(file_path, data_dir)
            zipf.write(file_path, arcname)

# List contents for user reference
zip_contents = zipfile.ZipFile(zip_path).namelist()

zip_contents
