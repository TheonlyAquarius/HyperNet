from dataclasses import dataclass
from typing import List, Tuple, Dict
import torch

@dataclass
class Entry:
    name: str
    shape: Tuple[int, ...]
    start: int
    end: int
    dtype: str

@dataclass
class Spec:
    total: int
    entries: List[Entry]

def build_spec(state: Dict[str, torch.Tensor]) -> Spec:
    entries = []
    cursor = 0
    for k, v in state.items():
        n = v.numel()
        entries.append(Entry(k, tuple(v.shape), cursor, cursor+n, str(v.dtype)))
        cursor += n
    return Spec(cursor, entries)

def flatten(state: Dict[str, torch.Tensor], spec: Spec) -> torch.Tensor:
    return torch.cat([state[e.name].reshape(-1) for e in spec.entries], dim=0)

def unflatten(vec: torch.Tensor, spec: Spec) -> Dict[str, torch.Tensor]:
    out: Dict[str, torch.Tensor] = {}
    for e in spec.entries:
        seg = vec[e.start:e.end]
        out[e.name] = seg.reshape(e.shape)
    return out
