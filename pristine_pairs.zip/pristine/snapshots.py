import os, glob

def list_snapshots(root: str, pattern: str):
    if "{i}" in pattern:
        pre, suf = pattern.split("{i}")
        cand = glob.glob(os.path.join(root, f"{pre}*{suf}"))
        def num(p):
            s = os.path.basename(p)[len(pre):]
            if suf:
                s = s[:-len(suf)]
            try: return int(s)
            except: return float("inf")
        return [p for p in sorted(cand, key=num) if os.path.isfile(p)]
    else:
        return sorted([p for p in glob.glob(os.path.join(root, pattern)) if os.path.isfile(p)])
