import os, argparse, json, torch
from torch.utils.data import Dataset, DataLoader
import torch.nn as nn
from pristine.utils import load_obj
from pristine.snapshots import list_snapshots
from pristine.schema import build_spec, flatten, unflatten
from pristine.pairs import all_pairs, maybe_reverse, sample_pairs
from pristine.map_mlp import MapMLP

class PairDataset(Dataset):
    def __init__(self, files, spec, pairs, predict="state"):
        self.files = files
        self.spec = spec
        self.pairs = pairs
        self.predict = predict  # "state" or "delta"
        self.states = [torch.load(f, map_location="cpu") for f in files]

    def __len__(self): return len(self.pairs)

    def __getitem__(self, idx):
        i, j = self.pairs[idx]
        a = self.states[i]
        b = self.states[j]
        fa = flatten(a, self.spec)
        fb = flatten(b, self.spec)
        if self.predict == "delta":
            y = fb - fa
        else:
            y = fb
        return fa, y, torch.tensor(i, dtype=torch.long), torch.tensor(j, dtype=torch.long)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--target_model", required=True, help="dotted path returning a torch.nn.Module")
    ap.add_argument("--snap_root", required=True)
    ap.add_argument("--pattern", required=True)
    ap.add_argument("--pair_mode", default="all", choices=["adjacent","all","gaps"])
    ap.add_argument("--gaps", default="", help="comma-separated integers, used when pair_mode=gaps")
    ap.add_argument("--include_reverse", action="store_true")
    ap.add_argument("--sample", type=int, default=0, help="optional number of pairs per epoch")
    ap.add_argument("--predict", default="state", choices=["state","delta"])
    ap.add_argument("--time_mode", default="diff", choices=["diff","both"])
    ap.add_argument("--batch", type=int, default=8)
    ap.add_argument("--epochs", type=int, default=10)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--out", default="map.pt")
    args = ap.parse_args()

    Build = load_obj(args.target_model)
    tm = Build()
    spec = build_spec(tm.state_dict())

    files = list_snapshots(args.snap_root, args.pattern)
    n = len(files)
    gaps = [int(x) for x in args.gaps.split(",") if x.strip().isdigit()] if args.gaps else None
    pairs = all_pairs(n, mode=args.pair_mode, gaps=gaps)
    pairs = maybe_reverse(pairs, args.include_reverse)

    ds = PairDataset(files, spec, pairs, predict=args.predict)
    dl = DataLoader(ds, batch_size=args.batch, shuffle=True)

    net = MapMLP(spec.total, time_mode=args.time_mode)
    opt = torch.optim.Adam(net.parameters(), lr=args.lr)
    loss_fn = nn.MSELoss()

    for epoch in range(1, args.epochs+1):
        total = 0.0
        seen = 0
        if args.sample and args.sample > 0:
            # sample a fresh subset each epoch
            from pristine.pairs import sample_pairs
            sel = sample_pairs(pairs, k=args.sample, seed=epoch)
            dl = DataLoader(PairDataset(files, spec, sel, predict=args.predict),
                            batch_size=args.batch, shuffle=True)
        for fa, y, i, j in dl:
            pred = net(fa, i, j)
            if args.predict == "delta":
                pred = pred  # network predicts delta
            loss = loss_fn(pred, y)
            opt.zero_grad(); loss.backward(); opt.step()
            total += loss.item() * fa.size(0)
            seen += fa.size(0)
        avg = total / max(1, seen)
        print(f"epoch {epoch} | loss {avg:.6f}")

    payload = {"state_dict": net.state_dict(), "meta": {"flat_dim": spec.total, "time_mode": args.time_mode, "predict": args.predict}}
    os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
    torch.save(payload, args.out)
    with open(os.path.splitext(args.out)[0] + ".spec.json", "w", encoding="utf-8") as f:
        json.dump({"total": spec.total, "entries": [e.__dict__ for e in spec.entries]}, f, indent=2)

if __name__ == "__main__":
    main()
