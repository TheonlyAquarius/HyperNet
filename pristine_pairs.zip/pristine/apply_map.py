import os, argparse, torch
from pristine.utils import load_obj
from pristine.schema import build_spec, flatten, unflatten
from pristine.map_mlp import MapMLP

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--target_model", required=True)
    ap.add_argument("--map", required=True)
    ap.add_argument("--start", required=False)
    ap.add_argument("--steps", type=int, default=1)
    ap.add_argument("--out_dir", required=True)
    args = ap.parse_args()

    Build = load_obj(args.target_model)
    tm = Build()
    spec = build_spec(tm.state_dict())

    payload = torch.load(args.map, map_location="cpu")
    meta = payload.get("meta", {})
    net = MapMLP(spec.total, time_mode=meta.get("time_mode","diff"))
    net.load_state_dict(payload["state_dict"])

    if args.start:
        state = torch.load(args.start, map_location="cpu")
    else:
        state = tm.state_dict()

    os.makedirs(args.out_dir, exist_ok=True)
    for k in range(args.steps+1):
        path = os.path.join(args.out_dir, f"step_{k:02d}.pt")
        torch.save(state, path)
        if k == args.steps: break
        fa = flatten(state, spec)
        i = torch.tensor(k)
        j = torch.tensor(k+1)
        out = net(fa, i, j)
        if meta.get("predict") == "delta":
            flat_next = fa + out
        else:
            flat_next = out
        state = unflatten(flat_next, spec)

if __name__ == "__main__":
    main()
