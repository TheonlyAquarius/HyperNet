from typing import List, Tuple
import random

def all_pairs(n: int, mode: str = "all", gaps: List[int] = None):
    idx = []
    if n <= 1: return idx
    if mode == "adjacent":
        for i in range(n-1):
            idx.append((i, i+1))
    elif mode == "all":
        for i in range(n-1):
            for j in range(i+1, n):
                idx.append((i, j))
    elif mode == "gaps":
        gaps = gaps or [1]
        for i in range(n-1):
            for g in gaps:
                j = i + g
                if j < n:
                    idx.append((i, j))
    else:
        raise ValueError(f"unknown mode: {mode}")
    return idx

def maybe_reverse(pairs: List[Tuple[int,int]], include_reverse: bool):
    if not include_reverse:
        return pairs
    out = pairs[:]
    out += [(j,i) for (i,j) in pairs]
    return out

def sample_pairs(pairs: List[Tuple[int,int]], k: int = None, seed: int = 0):
    if k is None or k <= 0 or k >= len(pairs):
        return pairs
    rng = random.Random(seed)
    return rng.sample(pairs, k)
