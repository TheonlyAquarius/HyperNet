import importlib

def load_obj(dotted: str):
    if ":" in dotted:
        mod, attr = dotted.split(":", 1)
    else:
        i = dotted.rfind(".")
        if i == -1:
            raise ValueError(f"Expected 'pkg.mod:Attr' or 'pkg.mod.Attr', got {dotted}")
        mod, attr = dotted[:i], dotted[i+1:]
    m = importlib.import_module(mod)
    if not hasattr(m, attr):
        raise ImportError(f"{attr} not found in {mod}")
    return getattr(m, attr)
