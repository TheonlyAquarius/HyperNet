import torch
import torch.nn as nn

class MapMLP(nn.Module):
    def __init__(self, flat_dim: int, time_dim: int = 64, hidden: int = 768, layers: int = 3, time_mode: str = "diff"):
        super().__init__()
        self.time_mode = time_mode  # "diff" or "both"
        in_t = 1 if time_mode == "diff" else 4  # (i,j,diff,sign)
        self.time = nn.Sequential(nn.Linear(in_t, time_dim), nn.ReLU(), nn.Linear(time_dim, time_dim))
        dims = [flat_dim + time_dim] + [hidden]*(layers-1) + [flat_dim]
        nets = []
        for i in range(len(dims)-1):
            nets.append(nn.Linear(dims[i], dims[i+1]))
            if i < len(dims)-2:
                nets.append(nn.ReLU())
        self.net = nn.Sequential(*nets)

    def forward(self, flat: torch.Tensor, i: torch.Tensor, j: torch.Tensor):
        d = (j - i).float()
        s = torch.sign(d).float()
        if self.time_mode == "diff":
            t = d.view(-1, 1)
        else:
            t = torch.stack([i.float(), j.float(), d, s], dim=-1).view(-1, 4)
        emb = self.time(t)
        if flat.dim() == 1 and emb.dim() == 2:
            emb = emb.squeeze(0)
        x = torch.cat([flat, emb], dim=-1)
        return self.net(x)
