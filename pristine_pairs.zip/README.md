# Pristine Pairs

Train a deterministic map over a parameter vector using pairs of snapshots (i -> j),
with options for multi-horizon pairs and reverse direction.

## Train

```bash
python -m pristine.train_map \
  --target_model examples.target_min:Build \
  --snap_root /path/to/snaps \
  --pattern "epoch_{i}.pt" \
  --pair_mode all \
  --include_reverse \
  --predict state \
  --time_mode both \
  --epochs 5 \
  --out map.pt
```

Modes:
- `pair_mode`: adjacent | all | gaps (use `--gaps 1,2,3`)
- `include_reverse`: also trains on j -> i
- `predict`: state (predict absolute) | delta (predict difference)
- `time_mode`: diff (j-i) | both (i, j, j-i, sign)

## Apply

```bash
python -m pristine.apply_map \
  --target_model examples.target_min:Build \
  --map map.pt \
  --start /path/to/snaps/epoch_0.pt \
  --steps 5 \
  --out_dir gen
```
