import torch.nn as nn

def Build():
    return nn.Sequential(nn.Flatten(), nn.Linear(32*32, 128), nn.ReLU(), nn.Linear(128, 10))
